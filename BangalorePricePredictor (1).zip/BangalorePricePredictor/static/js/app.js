document.addEventListener('DOMContentLoaded', function() {
    // Form validation
    const predictionForm = document.getElementById('predictionForm');
    
    if (predictionForm) {
        predictionForm.addEventListener('submit', function(event) {
            const area = document.getElementById('area').value;
            const bathrooms = document.getElementById('bathrooms').value;
            const bedrooms = document.getElementById('bedrooms').value;
            const location = document.getElementById('location').value;
            
            let isValid = true;
            let errorMessage = '';
            
            // Validate area
            if (!area || isNaN(area) || area < 100 || area > 10000) {
                isValid = false;
                errorMessage = 'Please enter a valid area between 100 and 10,000 sqft.';
            }
            
            // Validate bathrooms
            if (!bathrooms) {
                isValid = false;
                errorMessage = 'Please select number of bathrooms.';
            }
            
            // Validate bedrooms
            if (!bedrooms) {
                isValid = false;
                errorMessage = 'Please select number of bedrooms.';
            }
            
            // Validate location
            if (!location) {
                isValid = false;
                errorMessage = 'Please select a location.';
            }
            
            if (!isValid) {
                event.preventDefault();
                alert(errorMessage);
            }
        });
    }
    
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Add smooth scrolling to all links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
});
