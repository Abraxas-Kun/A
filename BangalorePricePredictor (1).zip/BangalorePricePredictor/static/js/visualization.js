// Chart style configurations
const chartConfig = {
    fontFamily: "'Open Sans', sans-serif",
    primaryColor: '#3498DB',
    secondaryColor: '#2C3E50',
    accentColor: '#E74C3C',
    backgroundColor: '#F5F7FA',
    gridColor: '#ECF0F1'
};

/**
 * Creates a chart showing average price by area range
 * @param {Object} data - Area-price data object with labels and values arrays
 */
function createAreaPriceChart(data) {
    const ctx = document.getElementById('areaPriceChart').getContext('2d');
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.labels,
            datasets: [{
                label: 'Average Price (Lakhs)',
                data: data.values,
                backgroundColor: chartConfig.primaryColor,
                borderColor: chartConfig.secondaryColor,
                borderWidth: 1,
                barPercentage: 0.6,
                borderRadius: 5
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        font: {
                            family: chartConfig.fontFamily
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `₹ ${context.parsed.y.toFixed(2)} Lakhs`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Price (Lakhs)',
                        font: {
                            family: chartConfig.fontFamily,
                            weight: 'bold'
                        }
                    },
                    grid: {
                        color: chartConfig.gridColor
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Area Range (sqft)',
                        font: {
                            family: chartConfig.fontFamily,
                            weight: 'bold'
                        }
                    },
                    grid: {
                        display: false
                    }
                }
            }
        }
    });
}

/**
 * Creates a chart showing average price by location
 * @param {Object} data - Location-price data object with labels and values arrays
 */
function createLocationPriceChart(data) {
    const ctx = document.getElementById('locationPriceChart').getContext('2d');
    
    // Get top 5 locations for better visibility
    const topLocations = {
        labels: data.labels.slice(0, 5),
        values: data.values.slice(0, 5)
    };
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: topLocations.labels,
            datasets: [{
                label: 'Average Price (Lakhs)',
                data: topLocations.values,
                backgroundColor: chartConfig.accentColor,
                borderColor: chartConfig.secondaryColor,
                borderWidth: 1,
                barPercentage: 0.8,
                borderRadius: 5
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        font: {
                            family: chartConfig.fontFamily
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `₹ ${context.parsed.x.toFixed(2)} Lakhs`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Price (Lakhs)',
                        font: {
                            family: chartConfig.fontFamily,
                            weight: 'bold'
                        }
                    },
                    grid: {
                        color: chartConfig.gridColor
                    }
                },
                y: {
                    title: {
                        display: true,
                        text: 'Location',
                        font: {
                            family: chartConfig.fontFamily,
                            weight: 'bold'
                        }
                    },
                    grid: {
                        display: false
                    }
                }
            }
        }
    });
}

/**
 * Creates a chart showing average price by BHK
 * @param {Object} data - BHK-price data object with labels and values arrays
 */
function createBhkPriceChart(data) {
    const ctx = document.getElementById('bhkPriceChart').getContext('2d');
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.labels.map(bhk => `${bhk} BHK`),
            datasets: [{
                label: 'Average Price (Lakhs)',
                data: data.values,
                backgroundColor: 'rgba(46, 204, 113, 0.2)',
                borderColor: '#2ECC71',
                borderWidth: 3,
                pointBackgroundColor: '#2ECC71',
                pointRadius: 5,
                tension: 0.3,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        font: {
                            family: chartConfig.fontFamily
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `₹ ${context.parsed.y.toFixed(2)} Lakhs`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Price (Lakhs)',
                        font: {
                            family: chartConfig.fontFamily,
                            weight: 'bold'
                        }
                    },
                    grid: {
                        color: chartConfig.gridColor
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Number of Bedrooms',
                        font: {
                            family: chartConfig.fontFamily,
                            weight: 'bold'
                        }
                    },
                    grid: {
                        display: false
                    }
                }
            }
        }
    });
}

// No need for horizontalBar fix since we're using bar with indexAxis: 'y'
