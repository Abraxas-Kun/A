#!/bin/bash
echo "Starting Property Price Prediction System..."
python3 launcher.py