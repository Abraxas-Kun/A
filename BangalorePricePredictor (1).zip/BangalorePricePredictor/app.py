import os
import logging
import pandas as pd
import io
import tempfile
from datetime import datetime
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, session
from ml_model import load_model, predict_price, train_model_with_data
from data_processor import get_locations, get_visualization_data, process_uploaded_data
from web_scraper import get_property_insights, search_property_data
from trend_analyzer import (
    get_time_period_dates, get_historical_data, calculate_price_change,
    calculate_volatility, prepare_trend_chart_data, generate_monthly_breakdown,
    forecast_prices, generate_forecast_text, generate_market_insights,
    compare_locations
)
import database

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "development-secret-key")

# Configurations
UPLOAD_FOLDER = 'uploaded_data'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# For database operations we use the database module
# Main database initialization happens in main.py to avoid circular imports

# Import models to make them available
import models

# Log initialization
logging.info("Loading Flask application")

# Global variables
model_status = "Using default model. Upload your own data for custom predictions."
model_source = "default"

# Load model and data on startup
model, scaler, encoder, model_features = load_model()
locations = get_locations()

@app.route('/')
def index():
    """Render the home page with prediction form"""
    global model_status, locations
    # Refresh locations list in case it changed after a data upload
    try:
        locations = get_locations()
    except Exception as e:
        logging.error(f"Error refreshing locations: {str(e)}")
    
    return render_template('index.html', locations=locations, model_status=model_status)

@app.route('/predict', methods=['POST'])
def predict():
    """Handle the prediction request"""
    try:
        # Get form data
        area = float(request.form.get('area'))
        bathrooms = int(request.form.get('bathrooms'))
        bedrooms = int(request.form.get('bedrooms'))
        location = request.form.get('location')
        
        # Generate prediction
        prediction, confidence = predict_price(
            model, scaler, encoder, model_features,
            area, bathrooms, bedrooms, location
        )
        
        # Return the prediction result
        return render_template(
            'prediction.html',
            prediction=prediction,
            confidence=confidence,
            area=area,
            bathrooms=bathrooms,
            bedrooms=bedrooms,
            location=location,
            model_source=model_source
        )
    except Exception as e:
        logging.error(f"Prediction error: {str(e)}")
        error_msg = str(e)
        # Make the error message more user-friendly
        if "could not convert string to float" in error_msg:
            error_msg = "There was a problem with your input data. Please try again with different values."
        elif "not in index" in error_msg:
            error_msg = "The selected location is not in our database. Please try a different location."
        
        return render_template('index.html', error=error_msg, locations=locations)

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    """Handle data file uploads"""
    global model, scaler, encoder, model_features, model_status, model_source, locations
    
    if request.method == 'POST':
        # Check if the post request has the file part
        if 'dataFile' not in request.files:
            return render_template('upload.html', error="No file part")
        
        file = request.files['dataFile']
        
        # If the user does not select a file, the browser submits an empty file
        if file.filename == '':
            return render_template('upload.html', error="No file selected")
        
        if file and file.filename.endswith('.csv'):
            try:
                # Read the file
                stream = io.StringIO(file.stream.read().decode("utf-8"), newline=None)
                data = pd.read_csv(stream)
                
                # Process the uploaded data
                processed_data = process_uploaded_data(data)
                
                # Save the file with timestamp to avoid overwrites
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"custom_data_{timestamp}.csv"
                filepath = os.path.join(UPLOAD_FOLDER, filename)
                processed_data.to_csv(filepath, index=False)
                
                # Train a new model with the uploaded data
                model, scaler, encoder, model_features = train_model_with_data(processed_data)
                
                # Update global variables
                model_status = f"Using custom model trained on {len(processed_data)} records from {file.filename}"
                model_source = "custom"
                
                # Refresh locations after new data upload
                locations = get_locations()
                
                return render_template('upload.html', 
                                       success=f"File uploaded and model trained successfully with {len(processed_data)} records")
            
            except Exception as e:
                logging.error(f"Upload error: {str(e)}")
                error_msg = f"Error analyzing your data: {str(e)}"
                # More user-friendly message
                user_friendly_msg = "There was an issue with your file. Please ensure your CSV has at least one column containing price data. The system will try to automatically detect other property features."
                return render_template('upload.html', error=user_friendly_msg)
        else:
            return render_template('upload.html', error="Only CSV files are allowed")
    
    # GET request - show the upload form
    return render_template('upload.html')

@app.route('/visualization')
def visualization():
    """Render the visualization dashboard"""
    area_price_data, location_price_data, bhk_price_data = get_visualization_data()
    
    return render_template(
        'visualization.html',
        area_price_data=area_price_data,
        location_price_data=location_price_data,
        bhk_price_data=bhk_price_data
    )

@app.route('/reset-model')
def reset_model():
    """Reset to the default model"""
    global model, scaler, encoder, model_features, model_status, model_source
    
    try:
        # Load the default model
        model, scaler, encoder, model_features = load_model(force_retrain=True)
        model_status = "Using default model. Upload your own data for custom predictions."
        model_source = "default"
        
        # Refresh locations
        locations = get_locations()
        
        return redirect(url_for('index'))
    except Exception as e:
        logging.error(f"Error resetting model: {str(e)}")
        return render_template('index.html', error="Failed to reset model: " + str(e), locations=locations)

@app.errorhandler(404)
def page_not_found(e):
    """Handle 404 errors"""
    return render_template('index.html', error="Page not found", locations=locations), 404

@app.route('/market-data', methods=['GET'])
def market_data():
    """Render the market data page"""
    return render_template('market_data.html')

@app.route('/trends', methods=['GET'])
def trends():
    """Render the historical trends page with analysis"""
    try:
        # Get query parameters
        location = request.args.get('location', '')
        time_period = request.args.get('time_period', '1year')
        property_type = request.args.get('property_type', 'all')
        bedrooms = request.args.get('bedrooms', 'all')
        chart_type = request.args.get('chart_type', 'line')
        compare_location = request.args.get('compare_location', '')
        
        # If no location specified, show empty form
        if not location:
            return render_template('trends.html', show_results=False)
        
        # Get date range based on time period
        start_date, end_date, time_period_label = get_time_period_dates(time_period)
        
        # Get historical data
        historical_df = get_historical_data(location, start_date, end_date, property_type, bedrooms)
        
        # If we have no data, show empty form with error
        if historical_df.empty:
            return render_template(
                'trends.html', 
                show_results=False, 
                error=f"No historical data found for {location} with the selected criteria."
            )
        
        # Calculate metrics
        price_change = calculate_price_change(historical_df)
        current_price = round(historical_df['avg_price'].iloc[-1], 2)
        volatility = calculate_volatility(historical_df)
        
        # Prepare trend chart data
        trend_data = prepare_trend_chart_data(historical_df, time_period)
        
        # Prepare monthly breakdown
        monthly_data = generate_monthly_breakdown(historical_df)
        
        # Prepare forecast
        forecast_data = forecast_prices(historical_df)
        forecast_direction, forecast_text = generate_forecast_text(historical_df, forecast_data)
        
        # Generate market insights
        market_insights = generate_market_insights(historical_df, location, property_type)
        
        # Handle comparison data if requested
        comparison_data = []
        if compare_location:
            comparison_data = compare_locations(
                location, compare_location, start_date, end_date, property_type, bedrooms
            )
            
            # Add comparison data to trend chart
            compare_df = get_historical_data(compare_location, start_date, end_date, property_type, bedrooms)
            if not compare_df.empty:
                compare_trend_data = prepare_trend_chart_data(compare_df, time_period)
                trend_data['compare_values'] = compare_trend_data['values']
        
        # Render the template with all data
        return render_template(
            'trends.html',
            show_results=True,
            location=location,
            time_period=time_period,
            property_type=property_type,
            bedrooms=bedrooms,
            chart_type=chart_type,
            compare_location=compare_location,
            compare=bool(compare_location and comparison_data),
            comparison_data=comparison_data,
            
            # Trend data
            trend_data=trend_data,
            time_period_label=time_period_label,
            price_change=price_change,
            current_price=current_price,
            volatility=volatility,
            monthly_data=monthly_data,
            
            # Forecast data
            forecast_data=forecast_data,
            forecast_direction=forecast_direction,
            forecast_text=forecast_text,
            
            # Insights
            market_insights=market_insights
        )
        
    except Exception as e:
        logging.error(f"Error generating trend analysis: {str(e)}")
        return render_template(
            'trends.html', 
            show_results=False, 
            error=f"An error occurred while analyzing trends: {str(e)}"
        )

@app.route('/search-property-data', methods=['POST'])
def search_property_data_api():
    """API endpoint to search for property data"""
    try:
        # Get search parameters
        location = request.form.get('location', '')
        property_type = request.form.get('property_type', None)
        
        if not location:
            return jsonify({'success': False, 'message': 'Location is required'})
        
        # Get property insights
        insights = get_property_insights(location, property_type)
        
        # If successful, return insights
        if insights['success']:
            # Train a model with the scraped data if enough data points are available
            if len(insights.get('raw_data', [])) >= 5:
                try:
                    # Convert raw data to DataFrame
                    scraped_df = pd.DataFrame(insights['raw_data'])
                    
                    # Add any required columns that might be missing
                    if 'balcony' not in scraped_df.columns:
                        scraped_df['balcony'] = 1
                    
                    # Save the file with timestamp
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    filename = f"scraped_data_{timestamp}.csv"
                    filepath = os.path.join(UPLOAD_FOLDER, filename)
                    scraped_df.to_csv(filepath, index=False)
                    
                    # Update global variables to indicate data source
                    global model, scaler, encoder, model_features, model_status, model_source
                    
                    # Train a new model with the scraped data
                    model, scaler, encoder, model_features = train_model_with_data(scraped_df)
                    
                    # Update model status
                    model_status = f"Using model trained on {len(scraped_df)} records from web data for {location}"
                    model_source = "scraped"
                    
                    # Add model training success info to the response
                    insights['model_trained'] = True
                    insights['model_message'] = f"Model trained successfully with {len(scraped_df)} records"
                except Exception as model_e:
                    logging.error(f"Error training model with scraped data: {str(model_e)}")
                    insights['model_trained'] = False
                    insights['model_message'] = f"Could not train model with scraped data: {str(model_e)}"
            
            return jsonify(insights)
        else:
            return jsonify(insights)
    
    except Exception as e:
        logging.error(f"Error searching property data: {str(e)}")
        return jsonify({
            'success': False,
            'message': f"Error processing request: {str(e)}"
        })

@app.errorhandler(500)
def server_error(e):
    """Handle 500 errors"""
    return render_template('index.html', error="Server error occurred", locations=locations), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
