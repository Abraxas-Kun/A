from datetime import datetime
from sqlalchemy import Column, String, Integer, Float, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from database import db

class Location(db.Model):
    """Location model to store area/location data"""
    __tablename__ = 'locations'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    city = Column(String(100), nullable=False)
    state = Column(String(100), nullable=True)
    country = Column(String(100), nullable=True)
    
    # Aggregate data for the location
    avg_price_per_sqft = Column(Float, nullable=True)
    popularity_index = Column(Float, nullable=True)
    
    # Relationships
    properties = relationship("Property", back_populates="location")
    price_history = relationship("PriceHistory", back_populates="location")
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<Location {self.name}, {self.city}>"

class Property(db.Model):
    """Property model to store property data"""
    __tablename__ = 'properties'
    
    id = Column(Integer, primary_key=True)
    area = Column(Float, nullable=False)  # in square feet
    bedrooms = Column(Integer, nullable=False)  # BHK
    bathrooms = Column(Integer, nullable=False)
    balcony = Column(Integer, nullable=True)
    property_type = Column(String(50), nullable=True)
    
    # Location foreign key
    location_id = Column(Integer, ForeignKey('locations.id'))
    location = relationship("Location", back_populates="properties")
    
    # Relationships
    price_history = relationship("PriceHistory", back_populates="property")
    predictions = relationship("PricePrediction", back_populates="property")
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<Property {self.id}: {self.bedrooms} BHK, {self.area} sqft>"

class PriceHistory(db.Model):
    """Historical price data for properties and locations"""
    __tablename__ = 'price_history'
    
    id = Column(Integer, primary_key=True)
    date = Column(DateTime, nullable=False, default=datetime.utcnow)
    price = Column(Float, nullable=False)  # in lakhs
    source = Column(String(100), nullable=True)  # where the data came from
    
    # Can be linked to either a specific property or just a location
    property_id = Column(Integer, ForeignKey('properties.id'), nullable=True)
    property = relationship("Property", back_populates="price_history")
    
    location_id = Column(Integer, ForeignKey('locations.id'), nullable=False)
    location = relationship("Location", back_populates="price_history")
    
    created_at = Column(DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f"<PriceHistory: {self.price} lakhs on {self.date.strftime('%Y-%m-%d')}>"

class PricePrediction(db.Model):
    """Model to store prediction results"""
    __tablename__ = 'price_predictions'
    
    id = Column(Integer, primary_key=True)
    predicted_price = Column(Float, nullable=False)
    confidence_score = Column(Float, nullable=True)
    model_version = Column(String(50), nullable=True)
    
    property_id = Column(Integer, ForeignKey('properties.id'))
    property = relationship("Property", back_populates="predictions")
    
    prediction_date = Column(DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f"<PricePrediction: {self.predicted_price} lakhs>"
