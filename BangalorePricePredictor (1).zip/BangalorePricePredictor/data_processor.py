import pandas as pd
import numpy as np
import json
import logging
import io
import os
import re

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Constants
DATA_URL = 'https://raw.githubusercontent.com/amankharwal/Website-data/master/Bengaluru_House_Data.csv'
UPLOADED_DATA_FOLDER = 'uploaded_data'

# Create uploads directory if it doesn't exist
if not os.path.exists(UPLOADED_DATA_FOLDER):
    os.makedirs(UPLOADED_DATA_FOLDER)

# Example data for fallback
EXAMPLE_DATA = '''
area,bath,balcony,price,size,site_location
1672,3,2,80.0,3 BHK,Electronic City
1750,3,2,135.0,3 BHK,Whitefield
1200,2,1,70.0,2 BHK,JP Nagar
1800,3,2,105.0,3 BHK,Indiranagar
1000,2,1,55.0,2 BHK,Koramangala
1365,3,1,85.0,3 BHK,HSR Layout
1680,3,2,185.0,3 BHK,Jayanagar
1100,2,1,60.0,2 BHK,Bannerghatta Road
2300,4,2,185.0,4 BHK,Hebbal
1500,3,1,110.0,3 BHK,Marathahalli
900,1,1,40.0,1 BHK,Bellandur
1800,3,2,150.0,3 BHK,Sarjapur Road
2400,4,3,240.0,4 BHK,Cunningham Road
1800,3,2,160.0,3 BHK,MG Road
850,1,1,42.0,1 BHK,Electronic City
1440,3,1,95.0,3 BHK,Whitefield
1100,2,1,62.0,2 BHK,JP Nagar
2100,3,2,170.0,3 BHK,Indiranagar
1600,3,2,110.0,3 BHK,Koramangala
1270,2,1,70.0,2 BHK,HSR Layout
'''

def load_data():
    """
    Load and preprocess the Bangalore housing dataset.
    Returns the processed dataframe.
    """
    try:
        logging.info("Loading dataset for processing")
        
        try:
            # Try to load from URL
            df = pd.read_csv(DATA_URL)
            logging.info("Successfully loaded data from URL for processing")
        except Exception as url_error:
            # If URL fails, use example data
            logging.warning(f"Failed to load data from URL: {str(url_error)}")
            logging.info("Using example data for processing instead")
            df = pd.read_csv(io.StringIO(EXAMPLE_DATA))
            logging.info(f"Loaded example data with {len(df)} records")
        
        # Basic data cleaning
        df = df.dropna()
        
        # Filter for columns we need
        df = df[['area', 'bath', 'balcony', 'price', 'size', 'site_location']]
        
        # Extract bedrooms from size (e.g., "2 BHK" -> 2)
        df['bhk'] = df['size'].str.extract('(\d+)').astype(int)
        
        # Remove outliers
        df = df[(df['price'] > 10) & (df['price'] < 500)]  # Prices in lakhs
        df = df[df['area'] < 10000]  # Area in sqft
        df = df[df['bath'] < 10]  # Reasonable number of bathrooms
        
        return df
    except Exception as e:
        logging.error(f"Error loading data: {str(e)}")
        # Return a minimal dataframe if all else fails
        return pd.DataFrame({
            'area': [1000, 1500, 2000, 1200, 1800],
            'bath': [2, 2, 3, 2, 3],
            'bhk': [2, 3, 3, 2, 3],
            'price': [50, 75, 100, 60, 90],
            'site_location': ['Electronic City', 'Whitefield', 'Indiranagar', 'JP Nagar', 'Koramangala'],
            'size': ['2 BHK', '3 BHK', '3 BHK', '2 BHK', '3 BHK'],
            'balcony': [1, 2, 2, 1, 2]
        })

def get_locations():
    """
    Get a sorted list of all locations in the dataset and database.
    Combines locations from both dataset and database.
    """
    locations = set()
    
    # Get locations from database
    try:
        from models import Location
        from database import db
        from flask import current_app
        
        # Make sure we have an application context
        if current_app:
            with db.engine.connect() as conn:
                result = conn.execute("SELECT name FROM locations")
                db_locations = [row[0] for row in result]
                locations.update(db_locations)
    except Exception as db_err:
        logging.warning(f"Database error getting locations: {str(db_err)}")
    
    # Get locations from dataset
    try:
        df = load_data()
        csv_locations = df['site_location'].unique().tolist()
        locations.update(csv_locations)
    except Exception as e:
        logging.error(f"Error getting locations from dataset: {str(e)}")
    
    # Fall back to defaults if no locations found
    if not locations:
        default_locations = ['Electronic City', 'Whitefield', 'Indiranagar', 'Jayanagar', 'JP Nagar']
        logging.warning("Using default locations list as no locations found in database or dataset")
        return sorted(default_locations)
    
    return sorted(list(locations))

def process_uploaded_data(df):
    """
    Advanced data processing with machine learning-inspired column detection.
    Uses a combination of text analysis, data type inference, and pattern recognition.
    
    Args:
        df: Pandas DataFrame from the uploaded file
        
    Returns:
        Processed DataFrame with standardized columns and data types
    """
    try:
        logging.info(f"Processing uploaded data with {len(df)} records")
        
        # Make a copy and preprocess
        processed_df = preprocess_dataframe(df)
        
        # Intelligent column classification
        column_mappings = identify_columns(processed_df)
        logging.info(f"Identified column mappings: {column_mappings}")
        
        # Create standardized DataFrame
        standard_df = standardize_dataframe(processed_df, column_mappings)
        
        # Validate and clean the standardized data
        standard_df = validate_and_clean_data(standard_df)
        
        # Log success
        logging.info(f"Successfully processed uploaded data, resulting in {len(standard_df)} clean records")
        
        # Return the standardized DataFrame
        return standard_df
        
    except Exception as e:
        logging.error(f"Error in advanced data processing: {str(e)}")
        raise

def preprocess_dataframe(df):
    """
    Perform initial preprocessing on the raw DataFrame.
    """
    # Make a copy to avoid modifying the original
    processed_df = df.copy()
    
    # Convert all column names to lowercase and strip whitespace
    processed_df.columns = [str(col).lower().strip() for col in processed_df.columns]
    
    # Handle completely empty rows or columns
    processed_df = processed_df.dropna(how='all')
    processed_df = processed_df.dropna(axis=1, how='all')
    
    # Try to infer better data types (numbers from strings, etc.)
    for col in processed_df.columns:
        # Skip columns that already have numeric type
        if np.issubdtype(processed_df[col].dtype, np.number):
            continue
            
        # Try to convert to numeric if it seems like it contains numbers
        if processed_df[col].apply(lambda x: str(x).replace('.', '').replace('-', '').isdigit()).mean() > 0.5:
            processed_df[col] = pd.to_numeric(processed_df[col], errors='coerce')
    
    return processed_df

def identify_columns(df):
    """
    Advanced column classification system with multi-level pattern recognition.
    Returns a mapping of standard column names to actual columns in the DataFrame.
    """
    # Initialize result dictionary
    column_mappings = {
        'area': None,
        'price': None,
        'site_location': None,
        'bhk': None,
        'bath': None,
        'balcony': None
    }
    
    # Define patterns and terms for each column type (word boundaries for better matching)
    pattern_dict = {
        'area': [
            r'(?i)(area|sq\.?ft|square.?fe?e?t|footage|plot.?size|property.?size)',
            ['area', 'sqft', 'sq.ft', 'size', 'square', 'squarefeet', 'square_feet', 'dimension']
        ],
        'price': [
            r'(?i)(price|cost|value|amount|rupees|rs\.?|rate|sale.?price|list.?price)',
            ['price', 'cost', 'value', 'amount', 'rupees', 'rs', 'rate', 'selling', 'asking']
        ],
        'site_location': [
            r'(?i)(location|place|site|address|city|town|locality|suburb|district|zone)',
            ['location', 'place', 'area', 'site', 'address', 'city', 'town', 'locality', 'region']
        ],
        'bhk': [
            r'(?i)(bhk|bed.?rooms?|no\.?\s*of\s*bed|br\b|bed.?r)',
            ['bhk', 'bedrooms', 'bed', 'bedroom', 'rooms', 'br', 'room']
        ],
        'bath': [
            r'(?i)(bath.?rooms?|no\.?\s*of\s*bath|wc\b|lavatory|toilet)',
            ['bath', 'bathroom', 'bathrooms', 'baths', 'washroom', 'toilet', 'wc']
        ],
        'balcony': [
            r'(?i)(balcon(?:y|ies)|patio|deck|terrace|porch)',
            ['balcony', 'balconies', 'patio', 'deck', 'terrace', 'porch']
        ]
    }
    
    # First pass: Direct pattern matching on column names
    for std_col, (pattern, terms) in pattern_dict.items():
        # Check regex pattern first
        regex_matches = [col for col in df.columns if bool(re.search(pattern, col))]
        if regex_matches:
            column_mappings[std_col] = regex_matches[0]
            continue
            
        # Then check simpler contained terms
        term_matches = [col for col in df.columns if any(term in col for term in terms)]
        if term_matches:
            column_mappings[std_col] = term_matches[0]
    
    # Second pass: Check column values for characteristics 
    
    # For price: likely to be one of the largest numerical columns
    if column_mappings['price'] is None:
        numeric_cols = df.select_dtypes(include=['number']).columns
        if len(numeric_cols) > 0:
            # Look at median values - price often has highest medians
            medians = df[numeric_cols].median()
            if not medians.empty:
                # Price is often the column with higher values, but not always the highest
                sorted_medians = medians.sort_values(ascending=False)
                # Try the top 2 if there are enough columns
                candidates = sorted_medians.index[:min(2, len(sorted_medians))]
                if len(candidates) > 0:
                    column_mappings['price'] = candidates[0]
                    logging.info(f"Inferred price column based on median values: {candidates[0]}")
    
    # For area: numeric column with moderate-high values but typically less than price
    if column_mappings['area'] is None and column_mappings['price'] is not None:
        numeric_cols = [col for col in df.select_dtypes(include=['number']).columns 
                       if col != column_mappings['price']]
        if len(numeric_cols) > 0:
            # Area often has the second highest median value after price
            medians = df[numeric_cols].median()
            if not medians.empty:
                area_col = medians.sort_values(ascending=False).index[0]
                column_mappings['area'] = area_col
                logging.info(f"Inferred area column based on median values: {area_col}")
    
    # For location: must be a string column with many unique values
    if column_mappings['site_location'] is None:
        obj_cols = df.select_dtypes(include=['object']).columns
        if len(obj_cols) > 0:
            # Location typically has many unique values relative to row count
            nunique_ratios = df[obj_cols].nunique() / len(df)
            if not nunique_ratios.empty:
                # Find columns with moderate unique values (not too few, not too many)
                location_candidates = nunique_ratios[(nunique_ratios > 0.01) & (nunique_ratios < 0.9)]
                if not location_candidates.empty:
                    column_mappings['site_location'] = location_candidates.index[0]
                    logging.info(f"Inferred location column: {location_candidates.index[0]}")
                else:
                    # If no good candidate, take the first string column
                    column_mappings['site_location'] = obj_cols[0]
                    logging.info(f"Using first string column as location: {obj_cols[0]}")
    
    # For bedrooms (bhk) - usually a small integer column, often with "2" as most common value
    if column_mappings['bhk'] is None:
        int_cols = [col for col in df.select_dtypes(include=['int', 'int64']).columns 
                   if col not in [column_mappings[k] for k in ['price', 'area'] if column_mappings[k] is not None]]
        if len(int_cols) > 0:
            # Find columns with small values (bedrooms typically 1-5)
            means = df[int_cols].mean()
            if not means.empty:
                small_cols = means[means < 6].index
                if len(small_cols) > 0:
                    # Among small value columns, bedrooms often has mode of 2 or 3
                    modes = df[small_cols].mode().iloc[0]
                    mode_2_3_cols = [col for col in small_cols if modes[col] in [2, 3]]
                    if mode_2_3_cols:
                        column_mappings['bhk'] = mode_2_3_cols[0]
                        logging.info(f"Inferred bedrooms column: {mode_2_3_cols[0]}")
                    else:
                        column_mappings['bhk'] = small_cols[0]
                        logging.info(f"Using first small-value column as bedrooms: {small_cols[0]}")
    
    # For bathrooms - similar to bedrooms but often smaller values
    if column_mappings['bath'] is None:
        int_cols = [col for col in df.select_dtypes(include=['int', 'int64', 'float']).columns 
                   if col not in [column_mappings[k] for k in ['price', 'area', 'bhk'] if column_mappings[k] is not None]]
        if len(int_cols) > 0:
            # Bathrooms typically have mean between 1-3
            means = df[int_cols].mean()
            if not means.empty:
                bath_candidates = means[(means >= 1) & (means <= 3)].index
                if len(bath_candidates) > 0:
                    column_mappings['bath'] = bath_candidates[0]
                    logging.info(f"Inferred bathrooms column: {bath_candidates[0]}")
    
    # Final check - ensure we have at least the essential columns
    essential_columns = ['price']
    missing_essential = [col for col in essential_columns if column_mappings[col] is None]
    
    if missing_essential:
        raise ValueError(f"Could not identify these essential columns: {missing_essential}")
    
    return column_mappings

def standardize_dataframe(df, column_mappings):
    """
    Create a standardized DataFrame with consistent column names.
    """
    standard_df = pd.DataFrame()
    
    # Map identified columns to standard names
    for std_col, actual_col in column_mappings.items():
        if actual_col is not None:
            if std_col == 'bhk' and 'size' not in standard_df.columns:
                # Check if the BHK column already has "BHK" text in it
                first_val = str(df[actual_col].iloc[0]).upper() if len(df) > 0 else ""
                if "BHK" not in first_val:
                    standard_df['size'] = df[actual_col].astype(str) + " BHK"
                else:
                    standard_df['size'] = df[actual_col].astype(str)
            standard_df[std_col] = df[actual_col]
    
    # Add default values for missing columns
    if 'area' not in standard_df.columns:
        standard_df['area'] = 1200  # Default area
        logging.warning("Using default value 1200 for missing area column")
    
    if 'site_location' not in standard_df.columns:
        standard_df['site_location'] = 'Unknown'
        logging.warning("Using 'Unknown' for missing location column")
    
    if 'bhk' not in standard_df.columns:
        standard_df['bhk'] = 2  # Default 2 bedrooms
        logging.warning("Using default value 2 for missing bedrooms column")
        
    if 'size' not in standard_df.columns:
        standard_df['size'] = standard_df['bhk'].astype(str) + " BHK"
    
    if 'bath' not in standard_df.columns:
        standard_df['bath'] = 2  # Default 2 bathrooms
        logging.warning("Using default value 2 for missing bathrooms column")
    
    if 'balcony' not in standard_df.columns:
        standard_df['balcony'] = 1  # Default 1 balcony
    
    return standard_df

def validate_and_clean_data(df):
    """
    Perform validation and cleaning on the standardized DataFrame.
    """
    # Make a copy to avoid modifying the input
    cleaned_df = df.copy()
    
    # Ensure correct data types
    cleaned_df['area'] = pd.to_numeric(cleaned_df['area'], errors='coerce')
    cleaned_df['bath'] = pd.to_numeric(cleaned_df['bath'], errors='coerce')
    cleaned_df['bhk'] = pd.to_numeric(cleaned_df['bhk'], errors='coerce')
    cleaned_df['price'] = pd.to_numeric(cleaned_df['price'], errors='coerce')
    cleaned_df['balcony'] = pd.to_numeric(cleaned_df['balcony'], errors='coerce')
    
    # Drop rows with invalid essential numeric values
    cleaned_df = cleaned_df.dropna(subset=['area', 'bath', 'bhk', 'price'])
    
    # Data cleaning based on domain knowledge
    
    # Area: typical residential properties are between 100-10000 sq ft
    cleaned_df = cleaned_df[(cleaned_df['area'] >= 100) & (cleaned_df['area'] <= 15000)]
    
    # Price: ensure positive values and handle extreme outliers
    # First, handle implausibly low prices (free properties)
    cleaned_df = cleaned_df[cleaned_df['price'] > 0]
    
    # Handle high outliers using IQR
    Q1 = cleaned_df['price'].quantile(0.25)
    Q3 = cleaned_df['price'].quantile(0.75)
    IQR = Q3 - Q1
    upper_bound = Q3 + 3 * IQR  # Less strict than typical 1.5*IQR to keep more data
    cleaned_df = cleaned_df[cleaned_df['price'] <= upper_bound]
    
    # Ensure reasonable bedroom and bathroom counts (1-10)
    cleaned_df = cleaned_df[(cleaned_df['bath'] >= 1) & (cleaned_df['bath'] <= 10)]
    cleaned_df = cleaned_df[(cleaned_df['bhk'] >= 1) & (cleaned_df['bhk'] <= 10)]
    
    # Ensure we have minimum data after cleaning
    if len(cleaned_df) < 5:
        remaining = len(cleaned_df)
        raise ValueError(f"Only {remaining} valid records remain after cleaning. Need at least 5 valid records.")
    
    logging.info(f"Data cleaning complete. Retained {len(cleaned_df)} of {len(df)} records.")
    return cleaned_df

def get_visualization_data():
    """
    Generate data for visualizations.
    Returns data for area vs price, location vs price, and BHK vs price charts.
    """
    try:
        df = load_data()
        
        # 1. Area vs Price Data
        # Create binned area ranges
        bins = [0, 500, 1000, 1500, 2000, 3000, 5000, 10000]
        labels = ['<500', '500-1000', '1000-1500', '1500-2000', '2000-3000', '3000-5000', '>5000']
        df['area_range'] = pd.cut(df['area'], bins=bins, labels=labels)
        
        area_price_data = df.groupby('area_range')['price'].mean().reset_index()
        area_price_data = area_price_data.rename(columns={'price': 'avg_price'})
        area_price_json = json.dumps({
            'labels': area_price_data['area_range'].tolist(),
            'values': area_price_data['avg_price'].round(2).tolist()
        })
        
        # 2. Location vs Price Data (Top 10 locations by count)
        top_locations = df['site_location'].value_counts().head(10).index.tolist()
        location_df = df[df['site_location'].isin(top_locations)]
        
        location_price_data = location_df.groupby('site_location')['price'].mean().reset_index()
        location_price_data = location_price_data.sort_values('price', ascending=False)
        location_price_json = json.dumps({
            'labels': location_price_data['site_location'].tolist(),
            'values': location_price_data['price'].round(2).tolist()
        })
        
        # 3. BHK vs Price Data
        bhk_price_data = df.groupby('bhk')['price'].mean().reset_index()
        bhk_price_data = bhk_price_data[bhk_price_data['bhk'] <= 5]  # Exclude unusual BHK values
        bhk_price_json = json.dumps({
            'labels': bhk_price_data['bhk'].tolist(),
            'values': bhk_price_data['price'].round(2).tolist()
        })
        
        return area_price_json, location_price_json, bhk_price_json
    
    except Exception as e:
        logging.error(f"Error generating visualization data: {str(e)}")
        # Return fallback data if needed
        area_price_fallback = json.dumps({
            'labels': ['<500', '500-1000', '1000-1500', '1500-2000', '2000-3000'],
            'values': [25, 40, 65, 85, 110]
        })
        
        location_price_fallback = json.dumps({
            'labels': ['Electronic City', 'Whitefield', 'Indiranagar', 'Jayanagar', 'JP Nagar'],
            'values': [60, 80, 120, 90, 75]
        })
        
        bhk_price_fallback = json.dumps({
            'labels': [1, 2, 3, 4, 5],
            'values': [30, 50, 80, 110, 150]
        })
        
        return area_price_fallback, location_price_fallback, bhk_price_fallback
