"""
Trend Analyzer Module for Property Price Prediction System
Handles historical trend analysis, forecasting, and market insights
"""

import datetime
import pandas as pd
import numpy as np
from sqlalchemy import func, desc
from dateutil.relativedelta import relativedelta
from sklearn.linear_model import LinearRegression
from models import Location, Property, PriceHistory
from database import db


def get_time_period_dates(time_period):
    """
    Calculate start and end dates based on the selected time period.
    
    Args:
        time_period: String representing the time period (e.g., '1month', '1year')
        
    Returns:
        Tuple of (start_date, end_date)
    """
    end_date = datetime.datetime.now()
    
    if time_period == '1month':
        start_date = end_date - relativedelta(months=1)
        period_label = "Last Month"
    elif time_period == '3months':
        start_date = end_date - relativedelta(months=3)
        period_label = "Last 3 Months"
    elif time_period == '6months':
        start_date = end_date - relativedelta(months=6)
        period_label = "Last 6 Months"
    elif time_period == '2years':
        start_date = end_date - relativedelta(years=2)
        period_label = "Last 2 Years"
    elif time_period == '5years':
        start_date = end_date - relativedelta(years=5)
        period_label = "Last 5 Years"
    else:  # Default to 1 year
        start_date = end_date - relativedelta(years=1)
        period_label = "Last Year"
        
    return start_date, end_date, period_label


def get_historical_data(location_name, start_date, end_date, property_type='all', bedrooms='all'):
    """
    Retrieve historical price data for a location within a date range.
    
    Args:
        location_name: Name of the location to analyze
        start_date: Start date for data retrieval
        end_date: End date for data retrieval
        property_type: Type of property to filter by (or 'all')
        bedrooms: Number of bedrooms to filter by (or 'all')
        
    Returns:
        DataFrame with historical price data
    """
    try:
        # Find the location
        location = db.session.query(Location).filter(
            Location.name.ilike(f"%{location_name}%") | 
            Location.city.ilike(f"%{location_name}%")
        ).first()
        
        if not location:
            # If we don't have this location in our database, create a dummy location
            # for trend demonstration purposes
            location = Location(
                name=location_name,
                city=location_name,
                country="India"
            )
            db.session.add(location)
            db.session.commit()
            
            # Generate some sample historical data for this new location
            generate_sample_price_history(location.id)
        
        # Base query for price history
        query = db.session.query(
            PriceHistory.date,
            func.avg(PriceHistory.price).label('avg_price'),
            func.count(PriceHistory.id).label('count')
        ).filter(
            PriceHistory.location_id == location.id,
            PriceHistory.date.between(start_date, end_date)
        )
        
        # Apply property type filter if specified
        if property_type != 'all':
            query = query.join(Property, PriceHistory.property_id == Property.id).filter(
                Property.property_type.ilike(f"%{property_type}%")
            )
        
        # Apply bedrooms filter if specified
        if bedrooms != 'all':
            if bedrooms == '5+':
                query = query.join(Property, PriceHistory.property_id == Property.id).filter(
                    Property.bedrooms >= 5
                )
            else:
                query = query.join(Property, PriceHistory.property_id == Property.id).filter(
                    Property.bedrooms == int(bedrooms)
                )
        
        # Group by month and order by date
        result = query.group_by(
            func.extract('year', PriceHistory.date),
            func.extract('month', PriceHistory.date)
        ).order_by(PriceHistory.date).all()
        
        # Convert to DataFrame
        df = pd.DataFrame([(r.date, r.avg_price, r.count) for r in result], 
                         columns=['date', 'avg_price', 'count'])
        
        return df
    
    except Exception as e:
        print(f"Error getting historical data: {str(e)}")
        # Return empty DataFrame with proper columns
        return pd.DataFrame(columns=['date', 'avg_price', 'count'])


def generate_sample_price_history(location_id):
    """
    Generate sample price history data for a new location.
    This is used when we don't have historical data for a location.
    
    Args:
        location_id: ID of the location to generate data for
    """
    end_date = datetime.datetime.now()
    start_date = end_date - relativedelta(years=5)
    
    # Create a date range for the past 5 years
    date_range = pd.date_range(start=start_date, end=end_date, freq='MS')  # Monthly start
    
    # Base price (random between 30 and 100 lakhs)
    base_price = np.random.uniform(30, 100)
    
    # Slight upward trend with seasonal variations and some random noise
    trend = np.linspace(0, 20, len(date_range))  # Upward trend
    seasonal = 5 * np.sin(np.arange(len(date_range)) * (2 * np.pi / 12))  # Seasonal cycle
    noise = np.random.normal(0, 2, len(date_range))  # Random noise
    
    prices = base_price + trend + seasonal + noise
    
    # Ensure all prices are positive
    prices = np.maximum(prices, 20)
    
    # Create and add price history records
    for i, date in enumerate(date_range):
        price_record = PriceHistory(
            date=date,
            price=prices[i],
            location_id=location_id,
            source="system_generated"
        )
        db.session.add(price_record)
    
    db.session.commit()


def calculate_price_change(df):
    """
    Calculate the price change percentage over the time period.
    
    Args:
        df: DataFrame with historical price data
        
    Returns:
        Price change percentage
    """
    if len(df) < 2:
        return 0
    
    first_price = df['avg_price'].iloc[0]
    last_price = df['avg_price'].iloc[-1]
    
    if first_price == 0:
        return 0
    
    price_change = ((last_price - first_price) / first_price) * 100
    return round(price_change, 2)


def calculate_volatility(df):
    """
    Calculate price volatility as the standard deviation of monthly percentage changes.
    
    Args:
        df: DataFrame with historical price data
        
    Returns:
        Volatility percentage
    """
    if len(df) < 2:
        return 0
    
    df['pct_change'] = df['avg_price'].pct_change() * 100
    volatility = df['pct_change'].std()
    return round(volatility, 2)


def prepare_trend_chart_data(df, time_period):
    """
    Prepare data for the trend chart.
    
    Args:
        df: DataFrame with historical price data
        time_period: The time period selected
        
    Returns:
        Dictionary with labels and values for the chart
    """
    if df.empty:
        return {"labels": [], "values": []}
    
    # Format dates based on time period
    if time_period in ['1month', '3months']:
        # For shorter periods, show date with day
        df['formatted_date'] = df['date'].dt.strftime('%b %d')
    elif time_period in ['6months', '1year']:
        # For medium periods, show month and year
        df['formatted_date'] = df['date'].dt.strftime('%b %Y')
    else:
        # For longer periods, show quarter and year
        df['quarter'] = df['date'].dt.to_period('Q')
        df['formatted_date'] = df['quarter'].astype(str)
        df = df.groupby('formatted_date').agg({'avg_price': 'mean'}).reset_index()
    
    chart_data = {
        "labels": df['formatted_date'].tolist(),
        "values": [round(price, 2) for price in df['avg_price'].tolist()]
    }
    
    return chart_data


def generate_monthly_breakdown(df):
    """
    Generate monthly breakdown data for the table.
    
    Args:
        df: DataFrame with historical price data
        
    Returns:
        List of dictionaries with monthly data
    """
    if df.empty:
        return []
    
    # Add month column
    df['month'] = df['date'].dt.strftime('%b %Y')
    
    # Calculate monthly change
    df['prev_price'] = df['avg_price'].shift(1)
    df['change'] = ((df['avg_price'] - df['prev_price']) / df['prev_price'] * 100).fillna(0)
    
    # Generate trend data for sparklines (last 6 data points or less)
    df['trend_data'] = None
    for i in range(len(df)):
        start_idx = max(0, i-5)
        trend = df['avg_price'].iloc[start_idx:i+1].tolist()
        df.at[i, 'trend_data'] = ','.join(map(str, [round(t, 2) for t in trend]))
    
    # Prepare monthly data
    monthly_data = []
    for _, row in df.iterrows():
        monthly_data.append({
            'month': row['month'],
            'avg_price': round(row['avg_price'], 2),
            'change': round(row['change'], 2),
            'listings': int(row['count']),
            'trend': row['trend_data']
        })
    
    # Reverse order to show most recent first
    monthly_data.reverse()
    
    return monthly_data


def forecast_prices(df, forecast_months=6):
    """
    Forecast future prices based on historical data.
    
    Args:
        df: DataFrame with historical price data
        forecast_months: Number of months to forecast
        
    Returns:
        Dictionary with forecast data for chart
    """
    if len(df) < 3:
        # Need at least 3 data points for reasonable forecast
        return {"labels": [], "historical": [], "forecast": [], "forecast_start": 0}
    
    # Create feature (X) as numeric time index
    df['time_idx'] = range(len(df))
    X = df[['time_idx']]
    y = df['avg_price']
    
    # Train linear regression model
    model = LinearRegression()
    model.fit(X, y)
    
    # Last date in our data
    last_date = df['date'].iloc[-1]
    
    # Create forecast dates
    forecast_dates = [last_date + relativedelta(months=i+1) for i in range(forecast_months)]
    
    # Convert to DataFrame for prediction
    forecast_df = pd.DataFrame({
        'date': forecast_dates,
        'time_idx': range(len(df), len(df) + forecast_months)
    })
    
    # Make predictions
    forecast_df['avg_price'] = model.predict(forecast_df[['time_idx']])
    
    # Format dates
    df['formatted_date'] = df['date'].dt.strftime('%b %Y')
    forecast_df['formatted_date'] = forecast_df['date'].dt.strftime('%b %Y')
    
    # Combine historical and forecast data for chart
    all_dates = df['formatted_date'].tolist() + forecast_df['formatted_date'].tolist()
    historical_values = [round(price, 2) for price in df['avg_price'].tolist()] + [None] * len(forecast_df)
    forecast_values = [None] * len(df) + [round(price, 2) for price in forecast_df['avg_price'].tolist()]
    
    return {
        "labels": all_dates,
        "historical": historical_values,
        "forecast": forecast_values,
        "forecast_start": len(df) - 1  # Index where forecast starts (for annotation)
    }


def generate_forecast_text(df, forecast_data):
    """
    Generate text description for the price forecast.
    
    Args:
        df: DataFrame with historical price data
        forecast_data: Dict with forecast data
        
    Returns:
        Tuple of (forecast_direction, forecast_text)
    """
    if not forecast_data['forecast'] or len(df) < 3:
        return "stable", "Insufficient historical data for reliable forecast."
    
    # Get the last historical price and the last forecast price
    last_historical = df['avg_price'].iloc[-1]
    last_forecast = forecast_data['forecast'][-1]
    
    # Calculate percentage change
    percent_change = ((last_forecast - last_historical) / last_historical) * 100
    
    # Determine direction
    if percent_change > 3:
        direction = "up"
        forecast_text = f"Based on historical trends, prices are expected to increase by approximately {round(percent_change, 1)}% over the next 6 months. This suggests a favorable market for sellers and investors looking for appreciation."
    elif percent_change < -3:
        direction = "down"
        forecast_text = f"Based on historical trends, prices are expected to decrease by approximately {round(abs(percent_change), 1)}% over the next 6 months. This may present buying opportunities, but sellers might want to reconsider timing."
    else:
        direction = "stable"
        forecast_text = "Based on historical trends, prices are expected to remain relatively stable over the next 6 months. This indicates a balanced market with neither buyers nor sellers having a significant advantage."
    
    return direction, forecast_text


def generate_market_insights(df, location_name, property_type="all"):
    """
    Generate market insights based on historical data.
    
    Args:
        df: DataFrame with historical price data
        location_name: Name of the location
        property_type: Type of property
        
    Returns:
        List of insight dictionaries
    """
    insights = []
    
    # Check if we have enough data
    if len(df) < 3:
        insights.append({
            "title": "Limited Data Available",
            "description": f"There is limited historical data available for {location_name}. Insights may not be comprehensive."
        })
        return insights
    
    # Calculate metrics
    recent_trend = calculate_recent_trend(df)
    seasonality = detect_seasonality(df)
    best_time = determine_best_time(df)
    market_position = assess_market_position(df)
    
    # Add insights based on calculations
    if recent_trend["direction"] == "up":
        insights.append({
            "title": "Rising Market",
            "description": f"Prices have been trending upward at {recent_trend['percentage']}% over the past {recent_trend['period']}. This indicates a seller's market."
        })
    elif recent_trend["direction"] == "down":
        insights.append({
            "title": "Declining Market",
            "description": f"Prices have been trending downward at {recent_trend['percentage']}% over the past {recent_trend['period']}. This could present buying opportunities."
        })
    else:
        insights.append({
            "title": "Stable Market",
            "description": f"Prices have remained relatively stable over the past {recent_trend['period']}, changing only by {recent_trend['percentage']}%."
        })
    
    if seasonality["detected"]:
        insights.append({
            "title": "Seasonal Patterns Detected",
            "description": f"The market shows seasonal patterns with price peaks typically in {seasonality['peak_months']} and lows in {seasonality['low_months']}."
        })
    
    insights.append({
        "title": f"Optimal Timing: {best_time['action']}",
        "description": f"{best_time['description']}"
    })
    
    insights.append({
        "title": f"Market Position: {market_position['position']}",
        "description": f"{market_position['description']}"
    })
    
    # Add a location-specific insight
    if property_type != "all":
        insights.append({
            "title": f"{property_type.title()} Market in {location_name}",
            "description": f"The {property_type} segment in {location_name} shows different characteristics compared to the overall market, with specific considerations for this property type."
        })
    
    return insights


def calculate_recent_trend(df):
    """Calculate the trend over the recent period."""
    periods = min(6, len(df))
    recent_df = df.tail(periods)
    
    first_price = recent_df['avg_price'].iloc[0]
    last_price = recent_df['avg_price'].iloc[-1]
    
    percentage = ((last_price - first_price) / first_price) * 100
    
    if percentage > 5:
        direction = "up"
    elif percentage < -5:
        direction = "down"
    else:
        direction = "stable"
    
    return {
        "direction": direction,
        "percentage": round(abs(percentage), 1),
        "period": f"{periods} months"
    }


def detect_seasonality(df):
    """Detect seasonal patterns in the data."""
    if len(df) < 12:  # Need at least a year of data
        return {"detected": False}
    
    # Add month column for grouping
    df['month'] = df['date'].dt.month
    
    # Calculate average price by month
    monthly_avg = df.groupby('month')['avg_price'].mean()
    
    # Find months with highest and lowest average prices
    peak_month = monthly_avg.idxmax()
    low_month = monthly_avg.idxmin()
    
    # Convert month numbers to names
    month_names = {
        1: 'January', 2: 'February', 3: 'March', 4: 'April',
        5: 'May', 6: 'June', 7: 'July', 8: 'August',
        9: 'September', 10: 'October', 11: 'November', 12: 'December'
    }
    
    # Check if there's significant difference between peak and low
    max_price = monthly_avg.max()
    min_price = monthly_avg.min()
    
    if (max_price - min_price) / min_price > 0.1:  # More than 10% difference
        return {
            "detected": True,
            "peak_months": month_names[peak_month],
            "low_months": month_names[low_month]
        }
    else:
        return {"detected": False}


def determine_best_time(df):
    """Determine the best time to buy or sell."""
    recent_trend = calculate_recent_trend(df)
    seasonality = detect_seasonality(df)
    
    if recent_trend["direction"] == "up":
        action = "Sell Now, Buy Later"
        description = "With prices trending upward, it's a good time to sell. If buying, consider waiting for a potential market correction."
    elif recent_trend["direction"] == "down":
        action = "Buy Now, Sell Later"
        description = "With prices trending downward, it's a good time to buy. If selling, consider waiting for the market to recover."
    else:
        if seasonality["detected"]:
            action = "Time Your Transaction"
            description = f"With stable prices overall but seasonal patterns, consider buying during {seasonality['low_months']} and selling during {seasonality['peak_months']}."
        else:
            action = "Balanced Market"
            description = "The market is currently balanced with stable prices. Neither buyers nor sellers have a significant advantage."
    
    return {
        "action": action,
        "description": description
    }


def assess_market_position(df):
    """Assess the current market position in the cycle."""
    # Calculate price change over different periods
    if len(df) >= 12:
        year_change = calculate_price_change(df.tail(12))
    else:
        year_change = calculate_price_change(df)
    
    recent_change = calculate_price_change(df.tail(min(3, len(df))))
    
    # Determine market phase
    if year_change > 10 and recent_change > 3:
        position = "Growth Phase"
        description = "The market is in a strong growth phase with consistent price appreciation. This typically attracts investors and can lead to increased competition."
    elif year_change > 5 and recent_change > 1:
        position = "Expansion Phase"
        description = "The market is expanding with moderate price growth. This phase often offers a balance of opportunity for both buyers and sellers."
    elif year_change < -5 and recent_change < -2:
        position = "Contraction Phase"
        description = "The market is contracting with notable price decreases. This may be an opportunity for buyers, but presents challenges for sellers."
    elif year_change < 0 and recent_change > 1:
        position = "Recovery Phase"
        description = "The market appears to be recovering from a previous downturn, with recent positive trends emerging after a period of decline."
    else:
        position = "Stabilization Phase"
        description = "The market is in a stabilization phase with minimal price changes. This generally indicates a balanced market environment."
    
    return {
        "position": position,
        "description": description
    }


def compare_locations(location1, location2, start_date, end_date, property_type='all', bedrooms='all'):
    """
    Compare two locations based on various metrics.
    
    Args:
        location1: Primary location name
        location2: Comparison location name
        start_date, end_date: Date range
        property_type, bedrooms: Filters
        
    Returns:
        List of comparison metrics
    """
    # Get data for both locations
    df1 = get_historical_data(location1, start_date, end_date, property_type, bedrooms)
    df2 = get_historical_data(location2, start_date, end_date, property_type, bedrooms)
    
    if df1.empty or df2.empty:
        return []
    
    # Calculate metrics
    current_price1 = df1['avg_price'].iloc[-1]
    current_price2 = df2['avg_price'].iloc[-1]
    
    price_change1 = calculate_price_change(df1)
    price_change2 = calculate_price_change(df2)
    
    volatility1 = calculate_volatility(df1)
    volatility2 = calculate_volatility(df2)
    
    # Average listings per month
    avg_listings1 = df1['count'].mean()
    avg_listings2 = df2['count'].mean()
    
    # Determine which location is better for investment
    invest_recommendation = location1 if price_change1 > price_change2 else location2
    
    # Prepare comparison data
    comparison = [
        {
            "metric": "Current Avg. Price (₹ Lakhs)",
            "location_value": round(current_price1, 2),
            "compare_value": round(current_price2, 2),
            "difference": f"{round(abs(current_price1 - current_price2), 2)} {'lower' if current_price1 < current_price2 else 'higher'}",
            "is_better": current_price1 < current_price2  # Assuming lower price is better for buyers
        },
        {
            "metric": "Price Appreciation",
            "location_value": f"{price_change1}%",
            "compare_value": f"{price_change2}%",
            "difference": f"{round(abs(price_change1 - price_change2), 2)}% {'lower' if price_change1 < price_change2 else 'higher'}",
            "is_better": price_change1 > price_change2  # Higher appreciation is better
        },
        {
            "metric": "Price Volatility",
            "location_value": f"{volatility1}%",
            "compare_value": f"{volatility2}%",
            "difference": f"{round(abs(volatility1 - volatility2), 2)}% {'lower' if volatility1 < volatility2 else 'higher'}",
            "is_better": volatility1 < volatility2  # Lower volatility is generally better
        },
        {
            "metric": "Avg. Monthly Listings",
            "location_value": round(avg_listings1),
            "compare_value": round(avg_listings2),
            "difference": f"{round(abs(avg_listings1 - avg_listings2))} {'fewer' if avg_listings1 < avg_listings2 else 'more'}",
            "is_better": avg_listings1 > avg_listings2  # More listings generally mean more options
        },
        {
            "metric": "Investment Recommendation",
            "location_value": "Recommended" if invest_recommendation == location1 else "-",
            "compare_value": "Recommended" if invest_recommendation == location2 else "-",
            "difference": f"{invest_recommendation} shows better investment potential",
            "is_better": invest_recommendation == location1
        }
    ]
    
    return comparison