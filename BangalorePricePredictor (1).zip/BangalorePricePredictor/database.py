"""
Database configuration for the Property Price Prediction System
This module initializes the SQLAlchemy database instance to avoid circular imports
"""

from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    pass


# Create the SQLAlchemy instance to be imported by other modules
db = SQLAlchemy(model_class=Base)


def init_app(app):
    """
    Initialize the database with the Flask app
    
    Args:
        app: Flask application instance
    """
    # Database configuration - check if DATABASE_URL exists, otherwise use a SQLite database
    if app.config.get("SQLALCHEMY_DATABASE_URI") is None:
        if app.config.get("DATABASE_URL"):
            app.config["SQLALCHEMY_DATABASE_URI"] = app.config.get("DATABASE_URL")
        else:
            # Use SQLite as fallback
            app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///property_price_prediction.db"

    app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
        "pool_recycle": 300,
        "pool_pre_ping": True,
    }
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
    
    # Initialize the app with the SQLAlchemy extension
    db.init_app(app)