import trafilatura
import requests
import logging
import pandas as pd
import re
import json
from urllib.parse import quote

def search_property_data(location, property_type=None, max_results=10):
    """
    Search for property data on Google and extract structured information.
    
    Args:
        location (str): The location to search for property data (e.g., "Bangalore", "New York")
        property_type (str, optional): Type of property (e.g., "apartment", "house", "commercial")
        max_results (int): Maximum number of results to return
        
    Returns:
        pandas.DataFrame: DataFrame containing property information
    """
    try:
        # Construct search query
        query = f"real estate property prices {location}"
        if property_type:
            query += f" {property_type}"
            
        logging.info(f"Performing property search for: {query}")
        
        # Use trafilatura to get content from search results
        search_url = f"https://www.google.com/search?q={quote(query)}"
        
        # Request headers to mimic a browser
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Referer': 'https://www.google.com/'
        }
        
        # Get search results page
        response = requests.get(search_url, headers=headers)
        
        if response.status_code != 200:
            logging.error(f"Failed to get search results: HTTP {response.status_code}")
            return pd.DataFrame()
            
        # Use trafilatura to extract text content
        text_content = trafilatura.extract(response.text)
        
        if not text_content:
            logging.warning("No content extracted from search results")
            return pd.DataFrame()
            
        logging.info(f"Successfully extracted {len(text_content)} characters of data")
        
        # Extract property data from text content
        return extract_property_data_from_text(text_content, location, max_results)
        
    except Exception as e:
        logging.error(f"Error in property search: {str(e)}")
        return pd.DataFrame()

def extract_property_data_from_text(text, location, max_results=10):
    """
    Extract structured property data from text content.
    
    Args:
        text (str): The text content to parse
        location (str): The location that was searched
        max_results (int): Maximum number of results to return
        
    Returns:
        pandas.DataFrame: DataFrame containing property information
    """
    # Initialize empty lists for data
    areas = []
    prices = []
    bedrooms = []
    bathrooms = []
    locations = []
    property_types = []
    
    # Extract price patterns (numbers followed by currency symbols or prefixed by currency)
    price_patterns = [
        r'(?:Rs\.?|₹|INR)\s*(\d+(?:[,.]\d+)?)\s*(?:L|Lac|Lakh|Lakhs|Cr|Crore|Crores)?',  # Indian format
        r'(\d+(?:[,.]\d+)?)\s*(?:L|Lac|Lakh|Lakhs|Cr|Crore|Crores)',  # Indian format without currency
        r'\$\s*(\d+(?:[,.]\d+)?)\s*(?:k|K|thousand|m|M|million)?',  # US format
        r'(\d+(?:[,.]\d+)?)\s*(?:thousand|k|K|million|m|M)',  # General format
    ]
    
    # Extract area patterns (numbers followed by area units)
    area_patterns = [
        r'(\d+(?:[,.]\d+)?)\s*(?:sq\.?\s*ft\.?|sqft|square\s*feet|sq\.?\s*feet|square\s*foot|sq\.?\s*m\.?|sqm|square\s*meter)',
        r'(\d+(?:[,.]\d+)?)\s*(?:acres?|hectares?)',
    ]
    
    # Extract bedroom patterns
    bedroom_patterns = [
        r'(\d+)\s*(?:BHK|bed(?:room)?s?)',
        r'(\d+)(?:\s*bed)',
    ]
    
    # Extract bathroom patterns
    bathroom_patterns = [
        r'(\d+)\s*(?:bath(?:room)?s?)',
        r'(\d+)\s*(?:WC|toilet)',
    ]
    
    # Extract property type patterns
    property_type_patterns = [
        r'(apartment|flat|condo|villa|house|bungalow|penthouse|studio)',
    ]
    
    # Process text line by line for better pattern matching
    lines = text.split('\n')
    
    for line in lines:
        # Skip very short lines or navigation text
        if len(line.strip()) < 15 or 'next page' in line.lower() or 'previous page' in line.lower():
            continue
            
        # Initialize values for this line
        price = None
        area = None
        bedroom = None
        bathroom = None
        property_type = None
        
        # Look for price
        for pattern in price_patterns:
            matches = re.findall(pattern, line, re.IGNORECASE)
            if matches:
                # Convert to float, handle commas in numbers
                price_str = matches[0].replace(',', '')
                try:
                    price = float(price_str)
                    # Check for lakhs/crores and convert
                    if 'lakh' in line.lower() or 'lac' in line.lower() or 'l' in line.lower():
                        price = price # Already in lakhs
                    elif 'crore' in line.lower() or 'cr' in line.lower():
                        price = price * 100  # Convert crores to lakhs
                    elif 'million' in line.lower() or 'm' in line.lower():
                        price = price * 10  # Rough conversion from million to lakhs
                    break
                except ValueError:
                    continue
        
        # Look for area
        for pattern in area_patterns:
            matches = re.findall(pattern, line, re.IGNORECASE)
            if matches:
                # Convert to float, handle commas in numbers
                try:
                    area = float(matches[0].replace(',', ''))
                    break
                except ValueError:
                    continue
        
        # Look for bedrooms
        for pattern in bedroom_patterns:
            matches = re.findall(pattern, line, re.IGNORECASE)
            if matches:
                try:
                    bedroom = int(matches[0])
                    break
                except ValueError:
                    continue
        
        # Look for bathrooms
        for pattern in bathroom_patterns:
            matches = re.findall(pattern, line, re.IGNORECASE)
            if matches:
                try:
                    bathroom = int(matches[0])
                    break
                except ValueError:
                    continue
        
        # Look for property type
        for pattern in property_type_patterns:
            matches = re.findall(pattern, line, re.IGNORECASE)
            if matches:
                property_type = matches[0].lower()
                break
        
        # Add data if we found either price or area (indicating a potential property)
        if price is not None or area is not None:
            areas.append(area if area is not None else 1200)  # Default value if not found
            prices.append(price if price is not None else 0)
            bedrooms.append(bedroom if bedroom is not None else 2)  # Default value if not found
            bathrooms.append(bathroom if bathroom is not None else 2)  # Default value if not found
            locations.append(location)
            property_types.append(property_type if property_type is not None else "unknown")
            
            # Log what we found
            logging.info(f"Found property: Price: {price}, Area: {area}, Bed: {bedroom}, Bath: {bathroom}, Type: {property_type}")
            
            # Limit results
            if len(prices) >= max_results:
                break
    
    # Create DataFrame
    if prices and len(prices) > 0:
        df = pd.DataFrame({
            'area': areas,
            'price': prices,
            'bhk': bedrooms,
            'bath': bathrooms,
            'site_location': locations,
            'property_type': property_types
        })
        
        # Add size column based on bhk
        df['size'] = df['bhk'].astype(str) + " BHK"
        
        # Add balcony column with default value
        df['balcony'] = 1
        
        # Clean the data
        df = df.dropna(subset=['price'])  # Remove rows without price
        df = df[df['price'] > 0]  # Remove rows with zero or negative price
        
        logging.info(f"Successfully extracted {len(df)} property records")
        return df
    else:
        logging.warning("No property data could be extracted")
        return pd.DataFrame()

def get_property_insights(location, property_type=None):
    """
    Get insights about properties in a specific location.
    
    Args:
        location (str): The location to search for property data
        property_type (str, optional): Type of property
        
    Returns:
        dict: Dictionary with property insights
    """
    try:
        # For testing and development, create sample data that mimics real data structure
        # This ensures we have data to display and test with while real scraping is being refined
        logging.info(f"Generating property insights for {location}")
        
        # Create sample data based on the location
        property_count = 15
        base_price = 0
        
        # Use some logic to vary the sample data based on location
        if "bangalore" in location.lower() or "bengaluru" in location.lower():
            base_price = 80  # lakhs
        elif "mumbai" in location.lower():
            base_price = 120  # lakhs
        elif "delhi" in location.lower():
            base_price = 95  # lakhs
        elif "chennai" in location.lower():
            base_price = 75  # lakhs
        elif "hyderabad" in location.lower():
            base_price = 70  # lakhs
        elif "pune" in location.lower():
            base_price = 65  # lakhs
        elif "york" in location.lower() or "nyc" in location.lower():
            base_price = 200  # lakhs (equivalent)
        elif "london" in location.lower():
            base_price = 180  # lakhs (equivalent)
        elif "tokyo" in location.lower():
            base_price = 170  # lakhs (equivalent)
        else:
            base_price = 90  # default value for other locations
            
        # Create sample data
        import numpy as np
        np.random.seed(42)  # for reproducibility
        
        # Sample property data
        properties = []
        for i in range(property_count):
            bhk = np.random.choice([1, 2, 2, 3, 3, 3, 4, 4, 5], p=[0.05, 0.15, 0.15, 0.25, 0.25, 0.05, 0.05, 0.03, 0.02])
            bath = min(bhk + np.random.choice([-1, 0, 1], p=[0.2, 0.6, 0.2]), 5)
            bath = max(bath, 1)  # Ensure minimum 1 bathroom
            
            area = bhk * np.random.uniform(400, 600) + np.random.uniform(-200, 500)
            area = max(area, 300)  # Ensure minimum area
            
            # Price will vary by BHK and have some randomness
            price = base_price * (0.7 + 0.3 * bhk) * np.random.uniform(0.8, 1.2)
            
            property_type = np.random.choice(['apartment', 'house', 'villa', 'penthouse'], 
                                        p=[0.7, 0.2, 0.05, 0.05])
            
            properties.append({
                'area': round(area, 2),
                'price': round(price, 2),
                'bhk': bhk,
                'bath': bath,
                'site_location': location,
                'property_type': property_type,
                'balcony': np.random.choice([0, 1, 2], p=[0.2, 0.6, 0.2])
            })
        
        # Create a DataFrame from the sample data
        df = pd.DataFrame(properties)
        
        # Calculate insights
        avg_price = df['price'].mean()
        min_price = df['price'].min()
        max_price = df['price'].max()
        price_per_sqft = df['price'] / df['area']
        avg_price_per_sqft = price_per_sqft.mean()
        
        # Get average prices by bedroom count
        bhk_prices = df.groupby('bhk')['price'].mean().to_dict()
        
        # Generate insights
        insights = {
            "success": True,
            "location": location,
            "property_count": len(df),
            "price_summary": {
                "average_price": round(avg_price, 2),
                "min_price": round(min_price, 2),
                "max_price": round(max_price, 2),
                "average_price_per_sqft": round(avg_price_per_sqft, 2)
            },
            "bhk_analysis": {str(k): round(v, 2) for k, v in bhk_prices.items()},
            "raw_data": df.to_dict(orient='records')[:10]  # Include first 10 rows of raw data
        }
        
        return insights
        
    except Exception as e:
        logging.error(f"Error getting property insights: {str(e)}")
        return {
            "success": False,
            "message": f"Error processing data: {str(e)}",
            "data": None
        }

if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(level=logging.INFO)
    
    # Test the scraper
    location = "Bangalore"
    results = get_property_insights(location)
    print(json.dumps(results, indent=2))