import os
from flask import Flask
import database
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logging.info("Loading Flask application")

# Create the app
app = Flask(__name__)

# Secret key for session management
app.secret_key = "development-secret-key"  # For production, use a secure random key

# Configure the database
# Use environment variable DATABASE_URL if available (for PostgreSQL)
if os.environ.get("DATABASE_URL"):
    app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
else:
    # Use SQLite as fallback
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///property_price_prediction.db"

app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Initialize the database with the app
with app.app_context():
    database.init_app(app)
    
    # Create all tables
    database.db.create_all()

# Import the routes after database initialization
from app import app as flask_app  # noqa: F401

# This allows importing the app from main
app = flask_app

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
