#!/usr/bin/env python3
"""
Property Price Prediction System Launcher
A simple GUI application to launch the main Flask application with one click.
"""

import os
import sys
import subprocess
import threading
import webbrowser
import time
import platform
from datetime import datetime

# Try to import tkinter for GUI
try:
    import tkinter as tk
    from tkinter import ttk, messagebox, scrolledtext
    TKINTER_AVAILABLE = True
except ImportError:
    TKINTER_AVAILABLE = False
    print("Tkinter not available. Running in command-line mode.")

# Global variables
SERVER_PROCESS = None
SERVER_URL = "http://localhost:5000"
LOG_FILE = "app_launcher_log.txt"
FLASK_APP = "main.py"

def get_timestamp():
    """Return a formatted timestamp for logging."""
    return datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")

def log_message(message, console=True, logfile=True):
    """Log a message to console and/or log file."""
    timestamp = get_timestamp()
    full_message = f"{timestamp} {message}"
    
    if console:
        print(full_message)
    
    if logfile:
        with open(LOG_FILE, "a") as f:
            f.write(full_message + "\n")
    
    return full_message

def is_server_running():
    """Check if the flask server is already running."""
    import socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    result = False
    try:
        sock.connect(('localhost', 5000))
        result = True
    except:
        result = False
    finally:
        sock.close()
    return result

def start_server():
    """Start the Flask server as a subprocess."""
    global SERVER_PROCESS
    
    if is_server_running():
        log_message("Server is already running.")
        return True
    
    log_message("Starting Flask server...")
    
    try:
        # Determine the command to start the server based on platform
        if platform.system() == "Windows":
            cmd = ["python", FLASK_APP]
        else:
            cmd = ["gunicorn", "--bind", "0.0.0.0:5000", "--reuse-port", "--reload", "main:app"]
        
        # Start the server process
        SERVER_PROCESS = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
            universal_newlines=True
        )
        
        # Wait a bit for server to start
        time.sleep(2)
        
        if SERVER_PROCESS.poll() is None:  # Process is still running
            log_message("Server started successfully.")
            return True
        else:
            # Get error message if process failed
            stdout, stderr = SERVER_PROCESS.communicate()
            error_msg = stderr or stdout
            log_message(f"Failed to start server: {error_msg}")
            return False
            
    except Exception as e:
        log_message(f"Error starting server: {str(e)}")
        return False

def stop_server():
    """Stop the Flask server."""
    global SERVER_PROCESS
    
    if SERVER_PROCESS:
        log_message("Stopping Flask server...")
        
        try:
            if platform.system() == "Windows":
                import signal
                SERVER_PROCESS.send_signal(signal.CTRL_BREAK_EVENT)
            else:
                SERVER_PROCESS.terminate()
                
            # Give it a moment to terminate gracefully
            SERVER_PROCESS.wait(timeout=5)
            SERVER_PROCESS = None
            log_message("Server stopped.")
            return True
            
        except Exception as e:
            log_message(f"Error stopping server: {str(e)}")
            try:
                SERVER_PROCESS.kill()
                SERVER_PROCESS = None
                log_message("Server killed.")
                return True
            except:
                log_message("Failed to kill server process.")
                return False
    else:
        log_message("No server process to stop.")
        return True

def open_browser():
    """Open the web browser to the application URL."""
    log_message("Opening browser...")
    webbrowser.open(SERVER_URL)

def log_reader(process, text_widget=None):
    """Read and log output from the server process."""
    for line in iter(process.stdout.readline, ''):
        if not line:
            break
        log_message(f"SERVER: {line.strip()}", console=True, logfile=True)
        
        if text_widget and TKINTER_AVAILABLE:
            text_widget.insert(tk.END, line)
            text_widget.see(tk.END)
    
    for line in iter(process.stderr.readline, ''):
        if not line:
            break
        log_message(f"SERVER ERROR: {line.strip()}", console=True, logfile=True)
        
        if text_widget and TKINTER_AVAILABLE:
            text_widget.insert(tk.END, f"ERROR: {line}", "error")
            text_widget.see(tk.END)

# GUI Application for Desktop Environments
class LauncherApp(tk.Tk):
    def __init__(self):
        super().__init__()
        
        self.title("Property Price Prediction System")
        self.geometry("800x600")
        self.minsize(640, 480)
        
        # Set icon if available
        try:
            self.iconbitmap("icon.ico")
        except:
            pass
        
        self.create_widgets()
        self.server_running = False
        self.check_server_status()
    
    def create_widgets(self):
        """Create the GUI elements."""
        # Main frame
        main_frame = ttk.Frame(self, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Heading
        heading = ttk.Label(
            main_frame, 
            text="Property Price Prediction System",
            font=("Helvetica", 24, "bold")
        )
        heading.pack(pady=(0, 20))
        
        # Status frame
        status_frame = ttk.Frame(main_frame)
        status_frame.pack(fill=tk.X, pady=10)
        
        self.status_label = ttk.Label(
            status_frame,
            text="Server Status: Checking...",
            font=("Helvetica", 12)
        )
        self.status_label.pack(side=tk.LEFT, padx=5)
        
        self.status_indicator = ttk.Label(
            status_frame,
            text="●",
            font=("Helvetica", 16),
            foreground="gray"
        )
        self.status_indicator.pack(side=tk.LEFT)
        
        # Buttons frame
        btn_frame = ttk.Frame(main_frame)
        btn_frame.pack(fill=tk.X, pady=20)
        
        self.start_btn = ttk.Button(
            btn_frame,
            text="Start Server",
            command=self.start_server_threaded,
            width=20
        )
        self.start_btn.pack(side=tk.LEFT, padx=5)
        
        self.browser_btn = ttk.Button(
            btn_frame,
            text="Open in Browser",
            command=open_browser,
            width=20,
            state=tk.DISABLED
        )
        self.browser_btn.pack(side=tk.LEFT, padx=5)
        
        self.stop_btn = ttk.Button(
            btn_frame,
            text="Stop Server",
            command=self.stop_server_threaded,
            width=20,
            state=tk.DISABLED
        )
        self.stop_btn.pack(side=tk.LEFT, padx=5)
        
        # Log frame with title
        log_label = ttk.Label(
            main_frame,
            text="Server Logs:",
            font=("Helvetica", 12, "bold")
        )
        log_label.pack(anchor=tk.W, pady=(20, 5))
        
        # Create a frame for the log display with a scrollbar
        log_frame = ttk.Frame(main_frame)
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(log_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Log text widget
        self.log_text = scrolledtext.ScrolledText(
            log_frame,
            wrap=tk.WORD,
            width=80,
            height=15
        )
        self.log_text.pack(fill=tk.BOTH, expand=True)
        
        # Configure the scrollbar to work with the text widget
        self.log_text.config(yscrollcommand=scrollbar.set)
        scrollbar.config(command=self.log_text.yview)
        
        # Configure tags for different types of messages
        self.log_text.tag_configure("error", foreground="red")
        self.log_text.tag_configure("success", foreground="green")
        self.log_text.tag_configure("warning", foreground="orange")
        
        # Footer
        footer = ttk.Label(
            self,
            text="© 2025 Property Price Prediction System",
            font=("Helvetica", 10),
            foreground="gray"
        )
        footer.pack(pady=10)
        
        # Load initial logs if they exist
        self.load_logs()
    
    def load_logs(self):
        """Load existing logs into the text widget."""
        if os.path.exists(LOG_FILE):
            with open(LOG_FILE, "r") as f:
                logs = f.readlines()
                # Only show the last 100 log lines to avoid performance issues
                for line in logs[-100:]:
                    if "ERROR" in line:
                        self.log_text.insert(tk.END, line, "error")
                    elif "SUCCESS" in line or "started successfully" in line:
                        self.log_text.insert(tk.END, line, "success")
                    elif "WARNING" in line:
                        self.log_text.insert(tk.END, line, "warning")
                    else:
                        self.log_text.insert(tk.END, line)
                self.log_text.see(tk.END)
    
    def add_log(self, message, tag=None):
        """Add a message to the log widget."""
        timestamp = get_timestamp()
        log_line = f"{timestamp} {message}\n"
        
        if tag:
            self.log_text.insert(tk.END, log_line, tag)
        else:
            self.log_text.insert(tk.END, log_line)
            
        self.log_text.see(tk.END)
        
        # Also write to the log file
        with open(LOG_FILE, "a") as f:
            f.write(log_line)
    
    def check_server_status(self):
        """Check if the server is running and update the status indicators."""
        if is_server_running():
            self.status_label.config(text="Server Status: Running")
            self.status_indicator.config(foreground="green")
            self.browser_btn.config(state=tk.NORMAL)
            self.stop_btn.config(state=tk.NORMAL)
            self.start_btn.config(state=tk.DISABLED)
            self.server_running = True
        else:
            self.status_label.config(text="Server Status: Stopped")
            self.status_indicator.config(foreground="red")
            self.browser_btn.config(state=tk.DISABLED)
            self.stop_btn.config(state=tk.DISABLED)
            self.start_btn.config(state=tk.NORMAL)
            self.server_running = False
        
        # Schedule the next status check
        self.after(5000, self.check_server_status)
    
    def start_server_threaded(self):
        """Start the server in a separate thread to avoid freezing the GUI."""
        self.add_log("Starting server...")
        self.start_btn.config(state=tk.DISABLED)
        
        def start_server_thread():
            global SERVER_PROCESS
            
            if start_server():
                self.add_log("Server started successfully!", "success")
                
                # Start a thread to read server output
                if SERVER_PROCESS:
                    log_thread = threading.Thread(
                        target=log_reader,
                        args=(SERVER_PROCESS, self.log_text),
                        daemon=True
                    )
                    log_thread.start()
            else:
                self.add_log("Failed to start server!", "error")
                self.start_btn.config(state=tk.NORMAL)
        
        threading.Thread(target=start_server_thread, daemon=True).start()
    
    def stop_server_threaded(self):
        """Stop the server in a separate thread."""
        self.add_log("Stopping server...")
        self.stop_btn.config(state=tk.DISABLED)
        
        def stop_server_thread():
            if stop_server():
                self.add_log("Server stopped successfully.", "success")
            else:
                self.add_log("Failed to stop server gracefully!", "error")
        
        threading.Thread(target=stop_server_thread, daemon=True).start()

# Command-line interface for environments without GUI
def cli_interface():
    """Command-line interface for the launcher."""
    print("\n" + "="*50)
    print("Property Price Prediction System - CLI Launcher")
    print("="*50 + "\n")
    
    while True:
        print("\nOptions:")
        print("1. Start Server")
        print("2. Open in Browser")
        print("3. Stop Server")
        print("4. Check Server Status")
        print("5. View Logs")
        print("0. Exit")
        
        choice = input("\nEnter your choice (0-5): ")
        
        if choice == "1":
            if is_server_running():
                print("Server is already running.")
            else:
                success = start_server()
                if success:
                    print("Server started successfully!")
                else:
                    print("Failed to start server. Check logs for details.")
        
        elif choice == "2":
            if is_server_running():
                open_browser()
                print("Opening browser...")
            else:
                print("Server is not running. Start the server first.")
        
        elif choice == "3":
            if is_server_running():
                success = stop_server()
                if success:
                    print("Server stopped successfully.")
                else:
                    print("Failed to stop server gracefully.")
            else:
                print("No server is running.")
        
        elif choice == "4":
            if is_server_running():
                print("Server Status: RUNNING")
            else:
                print("Server Status: STOPPED")
        
        elif choice == "5":
            if os.path.exists(LOG_FILE):
                with open(LOG_FILE, "r") as f:
                    logs = f.readlines()
                    # Show the last 20 log lines
                    print("\n--- Last 20 log entries ---")
                    for line in logs[-20:]:
                        print(line.strip())
                    print("-------------------------")
            else:
                print("No log file found.")
        
        elif choice == "0":
            if is_server_running():
                print("Stopping server before exit...")
                stop_server()
            print("Exiting launcher. Goodbye!")
            break
        
        else:
            print("Invalid option. Please try again.")

def main():
    """Main entry point."""
    # Create log file if it doesn't exist
    if not os.path.exists(LOG_FILE):
        with open(LOG_FILE, "w") as f:
            f.write(f"{get_timestamp()} Launcher initialized.\n")
    
    # Check if the Flask app exists
    if not os.path.exists(FLASK_APP):
        error_msg = f"Error: Could not find Flask application file '{FLASK_APP}'"
        log_message(error_msg)
        if TKINTER_AVAILABLE:
            tk.messagebox.showerror("Error", error_msg)
        else:
            print(error_msg)
        sys.exit(1)
    
    # Run GUI if tkinter is available, otherwise use CLI
    if TKINTER_AVAILABLE:
        app = LauncherApp()
        app.mainloop()
    else:
        cli_interface()

if __name__ == "__main__":
    main()